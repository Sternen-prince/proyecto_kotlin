package com.example.rre

import com.example.rre.entidades.Publicacion

interface OnPublicacionClickListener {
    fun onPublicacionClick(publicacion: Publicacion)
}
