package com.example.rre.ui.perfil

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.rre.entidades.Publicacion
import com.example.rre.PublicacionProvider

class PerfilViewModel : ViewModel() {
    private val _publicaciones = MutableLiveData<List<Publicacion>>()
    val publicaciones: LiveData<List<Publicacion>> = _publicaciones

    // Datos de perfil
    private val _nombre = MutableLiveData<String>()
    val nombre: LiveData<String> = _nombre

    private val _correo = MutableLiveData<String>()
    val correo: LiveData<String> = _correo

    init {
        val lista = PublicacionProvider.publicacionLista
        _publicaciones.value = lista

        if (lista.isNotEmpty()) {
            val autor = lista[0].autor
            _nombre.value = autor
            _correo.value = "${autor.replace(" ", ".")}@email.com"
        } else {
            _nombre.value = "Desconocido"
            _correo.value = "sin.correo@desconocido.com"
        }
    }



}