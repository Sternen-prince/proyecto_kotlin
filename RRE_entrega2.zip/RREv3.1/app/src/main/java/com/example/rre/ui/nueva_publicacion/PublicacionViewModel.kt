package com.example.rre.ui.nueva_publicacion

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.rre.PublicacionProvider
import com.example.rre.entidades.Publicacion

data class ValidationResult(val isValid: Boolean, val errorMessage: String? = null)

class PublicacionViewModel : ViewModel() {

    private val _titulo = MutableLiveData<String>()
    val titulo: LiveData<String> = _titulo

    private val _tipoAviso = MutableLiveData<String>()
    val tipoAviso: LiveData<String> = _tipoAviso

    private val _descripcion = MutableLiveData<String>()
    val descripcion: LiveData<String> = _descripcion

    private val _lugar = MutableLiveData<String>()
    val lugar: LiveData<String> = _lugar

    private val _imagenUri = MutableLiveData<String>()
    val imagenUri: LiveData<String> = _imagenUri

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    private val _publicacionExitosa = MutableLiveData<Boolean>()
    val publicacionExitosa: LiveData<Boolean> = _publicacionExitosa

    // Actualizadores
    fun actualizarTitulo(nuevoTitulo: String) { _titulo.value = nuevoTitulo }
    fun actualizarTipoAviso(nuevoTipo: String) { _tipoAviso.value = nuevoTipo }
    fun actualizarDescripcion(nuevaDescripcion: String) { _descripcion.value = nuevaDescripcion }
    fun actualizarLugar(nuevoLugar: String) { _lugar.value = nuevoLugar }
    fun actualizarImagen(uri: String?) { _imagenUri.value = uri ?: "" }

    // Validaciones
    fun validarTitulo(titulo: String) = when {
        titulo.isBlank() -> ValidationResult(false, "El título es obligatorio")
        titulo.length < 3 -> ValidationResult(false, "El título debe tener al menos 3 caracteres")
        else -> ValidationResult(true)
    }

    fun validarTipoAviso(tipo: String) = when {
        tipo.isBlank() -> ValidationResult(false, "El tipo de aviso es obligatorio")
        tipo.length < 3 -> ValidationResult(false, "El tipo debe tener al menos 3 caracteres")
        else -> ValidationResult(true)
    }

    fun validarDescripcion(descripcion: String) = when {
        descripcion.isBlank() -> ValidationResult(false, "La descripción es obligatoria")
        descripcion.length < 10 -> ValidationResult(false, "Debe tener al menos 10 caracteres")
        else -> ValidationResult(true)
    }

    fun validarLugar(lugar: String) = when {
        lugar.isBlank() -> ValidationResult(false, "El lugar es obligatorio")
        lugar.length < 2 -> ValidationResult(false, "El lugar debe tener al menos 2 caracteres")
        else -> ValidationResult(true)
    }

    fun validarFormularioCompleto(): ValidationResult {
        validarTitulo(_titulo.value ?: "").takeIf { !it.isValid }?.let { return it }
        validarTipoAviso(_tipoAviso.value ?: "").takeIf { !it.isValid }?.let { return it }
        validarDescripcion(_descripcion.value ?: "").takeIf { !it.isValid }?.let { return it }
        validarLugar(_lugar.value ?: "").takeIf { !it.isValid }?.let { return it }
        return ValidationResult(true)
    }

    fun publicarAviso() {
        _isLoading.value = true
        _errorMessage.value = null

        val validacion = validarFormularioCompleto()
        if (!validacion.isValid) {
            _isLoading.value = false
            _errorMessage.value = validacion.errorMessage
            return
        }

        val publicacion = Publicacion(
            titulo = _titulo.value ?: "",
            descripcion = _descripcion.value ?: "",
            tipoAviso = _tipoAviso.value ?: "",
            fecha = obtenerFechaActual(),
            lugar = _lugar.value ?: "",
            autor = "Armando Fuentes",
            photo = _imagenUri.value ?: ""
        )

        simularGuardado(publicacion)
    }

    private fun simularGuardado(publicacion: Publicacion) {
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            PublicacionProvider.publicacionLista.add(publicacion)
            _isLoading.value = false
            _publicacionExitosa.value = true
            limpiarFormulario()
        }, 1000)
    }

    private fun obtenerFechaActual(): String {
        val sdf = java.text.SimpleDateFormat("dd-MM-yyyy")
        return sdf.format(java.util.Date())
    }

    fun limpiarFormulario() {
        _titulo.value = ""
        _tipoAviso.value = ""
        _descripcion.value = ""
        _lugar.value = ""
        _imagenUri.value = ""
        _errorMessage.value = null
        _publicacionExitosa.value = false
    }

    fun resetearEstadoExito() {
        _publicacionExitosa.value = false
    }

    fun limpiarError() {
        _errorMessage.value = null
    }
}
